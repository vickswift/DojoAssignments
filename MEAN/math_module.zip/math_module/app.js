var mathlib = require('./mathlib')();

mathlib.add(7,4);
mathlib.multiply(11,10);
mathlib.square(2);
mathlib.random(3, 33);
