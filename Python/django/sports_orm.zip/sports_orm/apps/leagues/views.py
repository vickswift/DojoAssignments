from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		# "leagues": League.objects.filter(name__contains='baseball'),
		# "leagues": League.objects.filter(name__contains='women'),
		# "leagues": League.objects.filter(name__contains='hockey'),
		# "leagues": League.objects.exclude(name__contains='football'),
		# "leagues": League.objects.filter(name__contains='atlantic'),

		"teams": Team.objects.all(),
		# "teams": Team.objects.filter(location__contains='Dallas'),
		# "teams": Team.objects.filter(team_name__contains='Raptors'),
		# "teams": Team.objects.filter(location__contains='City'),
		# "teams": Team.objects.filter(team_name__startswith="T"),
		# "teams": Team.objects.order_by('location'),
		# "teams": Team.objects.order_by('-location'),

		"players": Player.objects.all(),
		# "players": Player.objects.filter(last_name__contains='Cooper'),
		# "players": Player.objects.filter(first_name__contains='Joshua'),
		# "players": Player.objects.filter(last_name__contains="Cooper").exclude(last_name__contains="Joshua"),
		# "players": Player.objects.filter(first_name__contains="Alexander")|
		# Player.objects.filter(first_name__contains="Alexander"),

	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
