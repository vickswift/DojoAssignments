from django.apps import AppConfig


class CoursesAppConfig(AppConfig):
    name = 'courses_app'
