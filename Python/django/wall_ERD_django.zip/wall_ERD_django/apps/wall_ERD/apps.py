from django.apps import AppConfig


class WallErdConfig(AppConfig):
    name = 'wall_ERD'
