from django.apps import AppConfig


class RandWordGeneratorConfig(AppConfig):
    name = 'rand_word_generator'
