from django.apps import AppConfig


class EmailValidationConfig(AppConfig):
    name = 'email_validation'
