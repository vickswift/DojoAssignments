from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'survey_form/index.html')

def show(request):
    if request.method == "POST":
        name = request.POST['name']
        location = request.POST['location']
        language = request.POST['language']
        message = request.POST['message']

        user_info = {
            'name': name,
            'location' : location,
            'language' : language,
            'message' : message
        }
    return render(request, 'survey_form/user-info.html', user_info)
