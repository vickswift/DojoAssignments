from django.apps import AppConfig


class SecretsDojoConfig(AppConfig):
    name = 'secrets_dojo'
